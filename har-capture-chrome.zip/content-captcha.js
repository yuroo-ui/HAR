// src/content-captcha.ts
var W = window;
function isDomCaptchaProviderFrame() {
  try {
    const h = location.hostname;
    return h.endsWith("challenges.cloudflare.com") || h === "challenges.cloudflare.com" || h.endsWith("hcaptcha.com") || h.endsWith("recaptcha.net") || h === "www.google.com" && location.pathname.includes("/recaptcha/") || h.endsWith("funcaptcha.com") || h.endsWith("arkoselabs.com");
  } catch {
    return false;
  }
}
if (isDomCaptchaProviderFrame()) {
} else if (W.__harSuiteCaptchaInstalled) {
} else {
  let send = function(hit) {
    const key = `${hit.type}|${hit.sitekey}`;
    if (seen.has(key)) return;
    seen.add(key);
    try {
      chrome.runtime.sendMessage({
        kind: "content-captcha-detected",
        type: hit.type,
        sitekey: hit.sitekey,
        source: hit.source ?? "dom",
        pageUrl: location.href,
        extra: hit.extra
      });
    } catch {
    }
  }, scan = function() {
    document.querySelectorAll(".g-recaptcha[data-sitekey], div[data-sitekey].g-recaptcha").forEach((el) => {
      const sitekey = el.dataset.sitekey ?? "";
      const size = el.dataset.size ?? "";
      if (sitekey)
        send({ type: size === "invisible" ? "recaptcha-v3" : "recaptcha-v2", sitekey });
    });
    document.querySelectorAll(".h-captcha[data-sitekey]").forEach((el) => {
      const sitekey = el.dataset.sitekey ?? "";
      if (sitekey) send({ type: "hcaptcha", sitekey });
    });
    document.querySelectorAll(".cf-turnstile[data-sitekey]").forEach((el) => {
      const sitekey = el.dataset.sitekey ?? "";
      if (sitekey) send({ type: "turnstile", sitekey });
    });
    document.querySelectorAll("[data-sitekey]").forEach((el) => {
      const sitekey = el.dataset.sitekey ?? "";
      if (!sitekey) return;
      const cls = el.className.toLowerCase();
      if (cls.includes("recaptcha") || cls.includes("h-captcha") || cls.includes("turnstile"))
        return;
      send({ type: "unknown", sitekey });
    });
    document.querySelectorAll(
      'script[src*="arkoselabs.com"], script[src*="funcaptcha.com"]'
    ).forEach((s) => {
      const m = s.src.match(/\/v2\/([0-9A-F-]{8,})\b/i);
      if (m) send({ type: "arkose", sitekey: m[1] });
    });
    document.querySelectorAll("iframe[src]").forEach((iframe) => {
      const src = iframe.src;
      try {
        const u = new URL(src);
        if ((u.hostname === "www.google.com" || u.hostname === "google.com" || u.hostname === "www.recaptcha.net" || u.hostname === "recaptcha.net") && u.pathname.includes("/recaptcha/")) {
          const k = u.searchParams.get("k");
          if (k) send({ type: u.pathname.includes("/enterprise/") ? "recaptcha-enterprise" : "recaptcha-v2", sitekey: k });
        }
        if (u.hostname.endsWith("hcaptcha.com")) {
          const m = u.pathname.match(/\/getcaptcha\/([^/?]+)/);
          if (m) send({ type: "hcaptcha", sitekey: m[1] });
          const sk = u.searchParams.get("sitekey");
          if (sk) send({ type: "hcaptcha", sitekey: sk });
        }
        if (u.hostname.endsWith("challenges.cloudflare.com")) {
          const sk = u.searchParams.get("sitekey");
          if (sk) send({ type: "turnstile", sitekey: sk });
          else {
            const mk = u.pathname.match(/\/turnstile\/v0\/[a-z0-9]+\/([A-Za-z0-9_-]{8,})/);
            if (mk) send({ type: "turnstile", sitekey: mk[1] });
          }
        }
      } catch {
      }
    });
    document.querySelectorAll("h-captcha").forEach((el) => {
      const sitekey = el.getAttribute("sitekey") ?? "";
      if (sitekey) send({ type: "hcaptcha", sitekey });
    });
    document.querySelectorAll(".cf-turnstile:not([data-sitekey])").forEach((el) => {
      const iframe = el.querySelector('iframe[src*="challenges.cloudflare.com"]');
      if (iframe) {
        try {
          const u = new URL(iframe.src);
          const sk = u.searchParams.get("sitekey");
          if (sk) send({ type: "turnstile", sitekey: sk });
          else {
            send({ type: "turnstile", sitekey: "" });
          }
        } catch {
        }
      }
    });
  }, schedule = function() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(() => {
      pending = false;
      scan();
    });
  };
  send2 = send, scan2 = scan, schedule2 = schedule;
  W.__harSuiteCaptchaInstalled = true;
  const seen = /* @__PURE__ */ new Set();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scan, { once: true });
  } else {
    scan();
  }
  let pending = false;
  const mo = new MutationObserver(schedule);
  mo.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["data-sitekey", "class", "src", "srcdoc"]
  });
  const hook = `
(function() {
  if (window.__harSuiteCaptchaHook) return;
  window.__harSuiteCaptchaHook = true;
  function relay(type, sitekey, extra) {
    window.postMessage({ __harSuiteCaptcha: true, type: type, sitekey: sitekey, extra: extra }, '*');
  }
  function wrap(obj, key, name) {
    if (!obj || typeof obj[key] !== 'function') return;
    if (obj[key].__harSuiteWrapped) return;
    var orig = obj[key];
    var wrapper = function() {
      try {
        var a0 = arguments[0], a1 = arguments[1];
        if (typeof a0 === 'string') relay(name, a0, a1 && a1.action ? { action: a1.action } : undefined);
        else if (a0 && typeof a0 === 'object' && a0.sitekey) relay(name, a0.sitekey, undefined);
        else if (a1 && a1.sitekey) relay(name, a1.sitekey, a1.action ? { action: a1.action } : undefined);
      } catch (e) {}
      return orig.apply(this, arguments);
    };
    wrapper.__harSuiteWrapped = true;
    obj[key] = wrapper;
  }
  function attach(g) {
    if (!g) return;
    wrap(g, 'execute', 'recaptcha-v3');
    wrap(g, 'render', 'recaptcha-v2');
    if (g.enterprise) {
      wrap(g.enterprise, 'execute', 'recaptcha-enterprise');
      wrap(g.enterprise, 'render', 'recaptcha-enterprise');
    }
  }
  // If grecaptcha is already present, attach immediately.
  if (window.grecaptcha) attach(window.grecaptcha);
  if (window.hcaptcha) { wrap(window.hcaptcha, 'execute', 'hcaptcha'); wrap(window.hcaptcha, 'render', 'hcaptcha'); }
  // Turnstile: DOM/sitekey detection is enough. Do NOT defineProperty(window.turnstile)
  // and do NOT wrap render/execute \u2014 that breaks CF challenge postMessage (Error 300030).
  // Intercept future grecaptcha/hcaptcha assignments only.
  var _g; try { Object.defineProperty(window, 'grecaptcha', {
    configurable: true,
    get: function() { return _g; },
    set: function(v) { _g = v; attach(v); }
  }); } catch (e) {}
  var _h; try { Object.defineProperty(window, 'hcaptcha', {
    configurable: true,
    get: function() { return _h; },
    set: function(v) { _h = v; if (v) { wrap(v, 'execute', 'hcaptcha'); wrap(v, 'render', 'hcaptcha'); } }
  }); } catch (e) {}
})();
`;
  try {
    const s = document.createElement("script");
    s.textContent = hook;
    (document.head || document.documentElement).appendChild(s);
    s.remove();
  } catch {
  }
  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || d.__harSuiteCaptcha !== true) return;
    const type = String(d.type ?? "");
    const sitekey = String(d.sitekey ?? "");
    if (!sitekey) return;
    send({ type, sitekey, source: "script", extra: d.extra });
  });
}
var send2;
var scan2;
var schedule2;

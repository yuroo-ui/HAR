// src/content-js-capture.ts
var MAX_CODE_LENGTH = 4096;
var _W = window;
if (_W.__harSuiteJsCapture) {
} else {
  let send = function(event) {
    try {
      chrome.runtime.sendMessage(event);
    } catch {
    }
  }, truncate = function(s) {
    if (!s) return void 0;
    return s.length > MAX_CODE_LENGTH ? s.slice(0, MAX_CODE_LENGTH) + "\u2026[truncated]" : s;
  }, captureInlineScripts = function() {
    document.querySelectorAll("script:not([src])").forEach((el) => {
      const code = el.textContent?.trim();
      if (code && code.length > 0) {
        send({
          kind: "js-capture",
          subtype: "inline-script",
          code: truncate(code),
          timestamp: Date.now(),
          pageUrl
        });
      }
    });
  }, scanNewScripts = function(mutations) {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        const el = node;
        if (el.tagName === "SCRIPT") {
          handleScriptElement(el);
        }
        el.querySelectorAll?.("script").forEach((s) => handleScriptElement(s));
      }
    }
  }, handleScriptElement = function(el) {
    if (seenScripts.has(el)) return;
    seenScripts.add(el);
    if (el.src) {
      send({
        kind: "js-capture",
        subtype: "dynamic-script-src",
        url: el.src,
        timestamp: Date.now(),
        pageUrl
      });
    } else {
      const code = el.textContent?.trim();
      if (code && code.length > 0) {
        send({
          kind: "js-capture",
          subtype: "dynamic-script-inline",
          code: truncate(code),
          timestamp: Date.now(),
          pageUrl
        });
      }
    }
  }, CapturedFunction = function(...args) {
    const body = args.length > 0 ? args[args.length - 1] : "";
    send({
      kind: "js-capture",
      subtype: "function-constructor",
      code: truncate(String(body)),
      timestamp: Date.now(),
      pageUrl
    });
    return new OrigFunction(...args);
  }, CapturedXHR = function() {
    const xhr = new OrigXHR();
    const origOpen = xhr.open.bind(xhr);
    const origSend = xhr.send.bind(xhr);
    let reqUrl;
    let reqMethod;
    xhr.open = function(method, url, async, user, password) {
      reqMethod = method;
      reqUrl = typeof url === "string" ? url : url.href;
      send({
        kind: "js-capture",
        subtype: "xhr-open",
        url: reqUrl,
        method: reqMethod,
        timestamp: Date.now(),
        pageUrl
      });
      return origOpen(method, url, async ?? true, user, password);
    };
    xhr.send = function(body) {
      if (body != null) {
        send({
          kind: "js-capture",
          subtype: "xhr-send",
          url: reqUrl,
          method: reqMethod,
          body: truncate(typeof body === "string" ? body : "[non-string body]"),
          timestamp: Date.now(),
          pageUrl
        });
      }
      return origSend(body);
    };
    return xhr;
  };
  send2 = send, truncate2 = truncate, captureInlineScripts2 = captureInlineScripts, scanNewScripts2 = scanNewScripts, handleScriptElement2 = handleScriptElement, CapturedFunction2 = CapturedFunction, CapturedXHR2 = CapturedXHR;
  _W.__harSuiteJsCapture = true;
  const pageUrl = location.href;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", captureInlineScripts, { once: true });
  } else {
    captureInlineScripts();
  }
  const seenScripts = /* @__PURE__ */ new WeakSet();
  const scriptObserver = new MutationObserver(scanNewScripts);
  scriptObserver.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  const origEval = window.eval;
  window.eval = function(code) {
    send({
      kind: "js-capture",
      subtype: "eval",
      code: truncate(String(code)),
      timestamp: Date.now(),
      pageUrl
    });
    return origEval.call(this, code);
  };
  Object.defineProperty(window.eval, "toString", { value: () => "function eval() { [native code] }" });
  const OrigFunction = Function;
  CapturedFunction.prototype = OrigFunction.prototype;
  Object.defineProperty(CapturedFunction, "toString", { value: () => "function Function() { [native code] }" });
  window.Function = CapturedFunction;
  const origFetch = window.fetch;
  window.fetch = async function(input, init) {
    let url;
    let method = init?.method ?? "GET";
    let reqBody;
    if (typeof input === "string") {
      url = input;
    } else if (input instanceof URL) {
      url = input.href;
    } else if (input instanceof Request) {
      url = input.url;
      method = init?.method ?? input.method;
    } else {
      url = String(input);
    }
    if (init?.body) {
      if (typeof init.body === "string") {
        reqBody = init.body;
      } else if (init.body instanceof ArrayBuffer) {
        reqBody = `[ArrayBuffer ${init.body.byteLength} bytes]`;
      } else if (init.body instanceof FormData) {
        reqBody = "[FormData]";
      } else if (init.body instanceof URLSearchParams) {
        reqBody = init.body.toString();
      }
    }
    send({
      kind: "js-capture",
      subtype: "fetch-request",
      url,
      method,
      body: truncate(reqBody),
      timestamp: Date.now(),
      pageUrl
    });
    const response = await origFetch.call(this, input, init);
    try {
      const clone = response.clone();
      const contentType = clone.headers.get("content-type") ?? "";
      if (contentType.includes("json") || contentType.includes("text") || contentType.includes("javascript") || contentType.includes("xml")) {
        const text = await clone.text();
        send({
          kind: "js-capture",
          subtype: "fetch-response",
          url,
          method,
          code: truncate(text),
          timestamp: Date.now(),
          pageUrl
        });
      }
    } catch {
    }
    return response;
  };
  Object.defineProperty(window.fetch, "toString", { value: () => "function fetch() { [native code] }" });
  const OrigXHR = XMLHttpRequest;
  CapturedXHR.prototype = OrigXHR.prototype;
  Object.defineProperty(CapturedXHR, "toString", { value: () => "function XMLHttpRequest() { [native code] }" });
  window.XMLHttpRequest = CapturedXHR;
  const origBeacon = navigator.sendBeacon.bind(navigator);
  navigator.sendBeacon = function(url, data) {
    let bodyStr;
    if (data != null) {
      if (typeof data === "string") bodyStr = data;
      else if (data instanceof Blob) bodyStr = `[Blob ${data.size} bytes]`;
      else if (data instanceof ArrayBuffer) bodyStr = `[ArrayBuffer ${data.byteLength} bytes]`;
      else if (data instanceof FormData) bodyStr = "[FormData]";
      else if (data instanceof URLSearchParams) bodyStr = data.toString();
    }
    send({
      kind: "js-capture",
      subtype: "beacon",
      url: typeof url === "string" ? url : url.href,
      method: "POST",
      body: truncate(bodyStr),
      timestamp: Date.now(),
      pageUrl
    });
    return origBeacon(url, data);
  };
  if ("serviceWorker" in navigator) {
    const origRegister = navigator.serviceWorker.register.bind(navigator.serviceWorker);
    navigator.serviceWorker.register = function(scriptURL, options) {
      send({
        kind: "js-capture",
        subtype: "sw-register",
        url: typeof scriptURL === "string" ? scriptURL : scriptURL.href,
        timestamp: Date.now(),
        pageUrl
      });
      return origRegister(scriptURL, options);
    };
  }
  const moduleObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        const el = node;
        if (el.tagName === "SCRIPT" && el.type === "module") {
          const src = el.src;
          if (src) {
            send({
              kind: "js-capture",
              subtype: "dynamic-script-src",
              url: src,
              timestamp: Date.now(),
              pageUrl
            });
          } else {
            const code = el.textContent?.trim();
            if (code) {
              send({
                kind: "js-capture",
                subtype: "inline-script",
                code: truncate(code),
                timestamp: Date.now(),
                pageUrl
              });
            }
          }
        }
      }
    }
  });
  moduleObserver.observe(document.documentElement, { childList: true, subtree: true });
  const OrigWorker = window.Worker;
  const OrigSharedWorker = window.SharedWorker;
  window.Worker = function(scriptURL, options) {
    send({
      kind: "js-capture",
      subtype: "worker-created",
      url: typeof scriptURL === "string" ? scriptURL : scriptURL.href,
      timestamp: Date.now(),
      pageUrl
    });
    return new OrigWorker(scriptURL, options);
  };
  window.Worker.prototype = OrigWorker.prototype;
  if (OrigSharedWorker) {
    window.SharedWorker = function(scriptURL, name) {
      send({
        kind: "js-capture",
        subtype: "worker-created",
        url: typeof scriptURL === "string" ? scriptURL : scriptURL.href,
        timestamp: Date.now(),
        pageUrl
      });
      return new OrigSharedWorker(scriptURL, name);
    };
    window.SharedWorker.prototype = OrigSharedWorker.prototype;
  }
  console.log("[HAR Suite] JS capture active \u2014 inline scripts, eval, fetch/XHR, beacon, workers");
}
var send2;
var truncate2;
var captureInlineScripts2;
var scanNewScripts2;
var handleScriptElement2;
var CapturedFunction2;
var CapturedXHR2;

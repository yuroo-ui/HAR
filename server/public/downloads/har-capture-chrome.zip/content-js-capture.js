// src/content-js-capture.ts
var MAX_CODE_LENGTH = 2e5;
var MAX_WS_PAYLOAD = 64e3;
var _W = window;
if (_W.__harSuiteJsCapture) {
} else {
  let send = function(event) {
    try {
      chrome.runtime.sendMessage(event);
    } catch {
    }
  }, truncate = function(s) {
    if (!s) return void 0;
    return s.length > MAX_CODE_LENGTH ? s.slice(0, MAX_CODE_LENGTH) + "\u2026[truncated]" : s;
  }, captureInlineScripts = function() {
    document.querySelectorAll("script:not([src])").forEach((el) => {
      const code = el.textContent?.trim();
      if (code && code.length > 0) {
        send({
          kind: "js-capture",
          subtype: "inline-script",
          code: truncate(code),
          timestamp: Date.now(),
          pageUrl
        });
      }
    });
  }, scanNewScripts = function(mutations) {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        const el = node;
        if (el.tagName === "SCRIPT") {
          handleScriptElement(el);
        }
        el.querySelectorAll?.("script").forEach((s) => handleScriptElement(s));
      }
    }
  }, handleScriptElement = function(el) {
    if (seenScripts.has(el)) return;
    seenScripts.add(el);
    if (el.src) {
      send({
        kind: "js-capture",
        subtype: "dynamic-script-src",
        url: el.src,
        timestamp: Date.now(),
        pageUrl
      });
    } else {
      const code = el.textContent?.trim();
      if (code && code.length > 0) {
        send({
          kind: "js-capture",
          subtype: "dynamic-script-inline",
          code: truncate(code),
          timestamp: Date.now(),
          pageUrl
        });
      }
    }
  }, CapturedFunction = function(...args) {
    const body = args.length > 0 ? args[args.length - 1] : "";
    send({
      kind: "js-capture",
      subtype: "function-constructor",
      code: truncate(String(body)),
      timestamp: Date.now(),
      pageUrl
    });
    return new OrigFunction(...args);
  }, bodyToString = function(body) {
    if (body == null) return void 0;
    if (typeof body === "string") return body;
    if (body instanceof URLSearchParams) return body.toString();
    if (body instanceof ArrayBuffer) return `[ArrayBuffer ${body.byteLength} bytes]`;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView?.(body)) return `[TypedArray ${body.byteLength} bytes]`;
    if (typeof Blob !== "undefined" && body instanceof Blob) return `[Blob ${body.size} bytes type=${body.type || ""}]`;
    if (typeof FormData !== "undefined" && body instanceof FormData) {
      try {
        const obj = {};
        body.forEach((v, k) => {
          obj[k] = typeof v === "string" ? v : `[File ${v.name || "blob"} ${v.size || 0}]`;
        });
        return JSON.stringify(obj);
      } catch {
        return "[FormData]";
      }
    }
    try {
      return String(body);
    } catch {
      return void 0;
    }
  }, CapturedXHR = function() {
    const xhr = new OrigXHR();
    const origOpen = xhr.open.bind(xhr);
    const origSend = xhr.send.bind(xhr);
    let reqUrl;
    let reqMethod;
    xhr.open = function(method, url, async, user, password) {
      reqMethod = method;
      reqUrl = typeof url === "string" ? url : url.href;
      send({
        kind: "js-capture",
        subtype: "xhr-open",
        url: reqUrl,
        method: reqMethod,
        timestamp: Date.now(),
        pageUrl
      });
      return origOpen(method, url, async ?? true, user, password);
    };
    const captureId = `jsxhr:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    xhr.send = function(body) {
      if (body != null) {
        send({
          kind: "js-capture",
          subtype: "xhr-send",
          url: reqUrl,
          method: reqMethod,
          body: truncate(typeof body === "string" ? body : bodyToString(body)),
          captureId,
          timestamp: Date.now(),
          pageUrl
        });
      }
      return origSend(body);
    };
    xhr.addEventListener("loadend", function() {
      try {
        const ct = xhr.getResponseHeader("content-type") || "";
        let bodyText;
        if (typeof xhr.responseText === "string") bodyText = xhr.responseText;
        send({
          kind: "js-capture",
          subtype: "xhr-load",
          url: reqUrl,
          method: reqMethod,
          status: xhr.status,
          mimeType: ct,
          code: truncate(bodyText),
          captureId,
          timestamp: Date.now(),
          pageUrl
        });
      } catch {
      }
    });
    return xhr;
  }, CapturedWebSocket = function(url, protocols) {
    const ws = protocols !== void 0 ? new OrigWebSocket(url, protocols) : new OrigWebSocket(url);
    const wsUrl = typeof url === "string" ? url : url.href;
    const captureId = `jsws:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    send({
      kind: "js-capture",
      subtype: "ws-open",
      url: wsUrl,
      method: "GET",
      captureId,
      timestamp: Date.now(),
      pageUrl
    });
    const origSend = ws.send.bind(ws);
    ws.send = function(data) {
      let payload;
      if (typeof data === "string") payload = data.slice(0, MAX_WS_PAYLOAD);
      else if (data instanceof ArrayBuffer) payload = `[ArrayBuffer ${data.byteLength} bytes]`;
      else if (ArrayBuffer.isView?.(data)) payload = `[TypedArray ${data.byteLength} bytes]`;
      else if (data instanceof Blob) payload = `[Blob ${data.size} bytes]`;
      else payload = String(data).slice(0, MAX_WS_PAYLOAD);
      send({
        kind: "js-capture",
        subtype: "ws-send",
        url: wsUrl,
        body: payload,
        direction: "sent",
        captureId,
        timestamp: Date.now(),
        pageUrl
      });
      return origSend(data);
    };
    ws.addEventListener("message", (ev) => {
      let payload;
      const data = ev.data;
      if (typeof data === "string") payload = data.slice(0, MAX_WS_PAYLOAD);
      else if (data instanceof ArrayBuffer) payload = `[ArrayBuffer ${data.byteLength} bytes]`;
      else if (data instanceof Blob) payload = `[Blob ${data.size} bytes]`;
      else payload = String(data).slice(0, MAX_WS_PAYLOAD);
      send({
        kind: "js-capture",
        subtype: "ws-message",
        url: wsUrl,
        body: payload,
        direction: "received",
        captureId,
        timestamp: Date.now(),
        pageUrl
      });
    });
    ws.addEventListener("close", () => {
      send({
        kind: "js-capture",
        subtype: "ws-close",
        url: wsUrl,
        captureId,
        timestamp: Date.now(),
        pageUrl
      });
    });
    return ws;
  };
  send2 = send, truncate2 = truncate, captureInlineScripts2 = captureInlineScripts, scanNewScripts2 = scanNewScripts, handleScriptElement2 = handleScriptElement, CapturedFunction2 = CapturedFunction, bodyToString2 = bodyToString, CapturedXHR2 = CapturedXHR, CapturedWebSocket2 = CapturedWebSocket;
  _W.__harSuiteJsCapture = true;
  const pageUrl = location.href;
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", captureInlineScripts, { once: true });
  } else {
    captureInlineScripts();
  }
  const seenScripts = /* @__PURE__ */ new WeakSet();
  const scriptObserver = new MutationObserver(scanNewScripts);
  scriptObserver.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  const origEval = window.eval;
  window.eval = function(code) {
    send({
      kind: "js-capture",
      subtype: "eval",
      code: truncate(String(code)),
      timestamp: Date.now(),
      pageUrl
    });
    return origEval.call(this, code);
  };
  Object.defineProperty(window.eval, "toString", { value: () => "function eval() { [native code] }" });
  const OrigFunction = Function;
  CapturedFunction.prototype = OrigFunction.prototype;
  Object.defineProperty(CapturedFunction, "toString", { value: () => "function Function() { [native code] }" });
  window.Function = CapturedFunction;
  const origFetch = window.fetch;
  window.fetch = async function(input, init) {
    let url;
    let method = init?.method ?? "GET";
    let reqBody;
    let headers;
    const captureId = `jsfetch:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    if (typeof input === "string") {
      url = input;
    } else if (input instanceof URL) {
      url = input.href;
    } else if (input instanceof Request) {
      url = input.url;
      method = init?.method ?? input.method;
      try {
        if (!init?.body && input.clone) {
          const ct = input.headers?.get?.("content-type") || "";
          if (ct.includes("json") || ct.includes("text") || ct.includes("x-www-form-urlencoded")) {
            reqBody = await input.clone().text();
          }
        }
      } catch {
      }
    } else {
      url = String(input);
    }
    if (init?.body != null) reqBody = bodyToString(init.body);
    try {
      if (init?.headers) {
        headers = {};
        if (init.headers instanceof Headers) init.headers.forEach((v, k) => {
          headers[k] = v;
        });
        else if (Array.isArray(init.headers)) for (const [k, v] of init.headers) headers[k] = String(v);
        else headers = { ...init.headers };
      }
    } catch {
    }
    send({
      kind: "js-capture",
      subtype: "fetch-request",
      url,
      method,
      headers,
      body: truncate(reqBody),
      captureId,
      timestamp: Date.now(),
      pageUrl
    });
    const response = await origFetch.call(this, input, init);
    try {
      const clone = response.clone();
      const contentType = clone.headers.get("content-type") ?? "";
      const respHeaders = {};
      clone.headers.forEach((v, k) => {
        respHeaders[k] = v;
      });
      let text;
      if (contentType.includes("json") || contentType.includes("text") || contentType.includes("javascript") || contentType.includes("xml") || contentType.includes("html") || contentType === "") {
        text = await clone.text();
      } else {
        text = `[binary content-type=${contentType}]`;
      }
      send({
        kind: "js-capture",
        subtype: "fetch-response",
        url,
        method,
        headers: respHeaders,
        code: truncate(text),
        status: response.status,
        mimeType: contentType,
        captureId,
        timestamp: Date.now(),
        pageUrl
      });
    } catch {
    }
    return response;
  };
  Object.defineProperty(window.fetch, "toString", { value: () => "function fetch() { [native code] }" });
  const OrigXHR = XMLHttpRequest;
  CapturedXHR.prototype = OrigXHR.prototype;
  Object.defineProperty(CapturedXHR, "toString", { value: () => "function XMLHttpRequest() { [native code] }" });
  window.XMLHttpRequest = CapturedXHR;
  const origBeacon = navigator.sendBeacon.bind(navigator);
  navigator.sendBeacon = function(url, data) {
    let bodyStr;
    if (data != null) {
      if (typeof data === "string") bodyStr = data;
      else if (data instanceof Blob) bodyStr = `[Blob ${data.size} bytes]`;
      else if (data instanceof ArrayBuffer) bodyStr = `[ArrayBuffer ${data.byteLength} bytes]`;
      else if (data instanceof FormData) bodyStr = "[FormData]";
      else if (data instanceof URLSearchParams) bodyStr = data.toString();
    }
    send({
      kind: "js-capture",
      subtype: "beacon",
      url: typeof url === "string" ? url : url.href,
      method: "POST",
      body: truncate(bodyStr),
      timestamp: Date.now(),
      pageUrl
    });
    return origBeacon(url, data);
  };
  if ("serviceWorker" in navigator) {
    const origRegister = navigator.serviceWorker.register.bind(navigator.serviceWorker);
    navigator.serviceWorker.register = function(scriptURL, options) {
      send({
        kind: "js-capture",
        subtype: "sw-register",
        url: typeof scriptURL === "string" ? scriptURL : scriptURL.href,
        timestamp: Date.now(),
        pageUrl
      });
      return origRegister(scriptURL, options);
    };
  }
  const moduleObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        const el = node;
        if (el.tagName === "SCRIPT" && el.type === "module") {
          const src = el.src;
          if (src) {
            send({
              kind: "js-capture",
              subtype: "dynamic-script-src",
              url: src,
              timestamp: Date.now(),
              pageUrl
            });
          } else {
            const code = el.textContent?.trim();
            if (code) {
              send({
                kind: "js-capture",
                subtype: "inline-script",
                code: truncate(code),
                timestamp: Date.now(),
                pageUrl
              });
            }
          }
        }
      }
    }
  });
  moduleObserver.observe(document.documentElement, { childList: true, subtree: true });
  const OrigWorker = window.Worker;
  const OrigSharedWorker = window.SharedWorker;
  window.Worker = function(scriptURL, options) {
    send({
      kind: "js-capture",
      subtype: "worker-created",
      url: typeof scriptURL === "string" ? scriptURL : scriptURL.href,
      timestamp: Date.now(),
      pageUrl
    });
    return new OrigWorker(scriptURL, options);
  };
  window.Worker.prototype = OrigWorker.prototype;
  if (OrigSharedWorker) {
    window.SharedWorker = function(scriptURL, name) {
      send({
        kind: "js-capture",
        subtype: "worker-created",
        url: typeof scriptURL === "string" ? scriptURL : scriptURL.href,
        timestamp: Date.now(),
        pageUrl
      });
      return new OrigSharedWorker(scriptURL, name);
    };
    window.SharedWorker.prototype = OrigSharedWorker.prototype;
  }
  const OrigWebSocket = window.WebSocket;
  CapturedWebSocket.prototype = OrigWebSocket.prototype;
  Object.defineProperty(CapturedWebSocket, "CONNECTING", { value: OrigWebSocket.CONNECTING });
  Object.defineProperty(CapturedWebSocket, "OPEN", { value: OrigWebSocket.OPEN });
  Object.defineProperty(CapturedWebSocket, "CLOSING", { value: OrigWebSocket.CLOSING });
  Object.defineProperty(CapturedWebSocket, "CLOSED", { value: OrigWebSocket.CLOSED });
  Object.defineProperty(CapturedWebSocket, "toString", { value: () => "function WebSocket() { [native code] }" });
  window.WebSocket = CapturedWebSocket;
  console.log("[HAR Suite] JS capture active \u2014 fetch/XHR body, WS frames, eval, beacon, workers");
}
var send2;
var truncate2;
var captureInlineScripts2;
var scanNewScripts2;
var handleScriptElement2;
var CapturedFunction2;
var bodyToString2;
var CapturedXHR2;
var CapturedWebSocket2;

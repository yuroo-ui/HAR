var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/remote-store.ts
var remote_store_exports = {};
__export(remote_store_exports, {
  REMOTE_BRANCH_KEY: () => REMOTE_BRANCH_KEY,
  REMOTE_BRIDGE_HOST: () => REMOTE_BRIDGE_HOST,
  REMOTE_BRIDGE_WSS: () => REMOTE_BRIDGE_WSS,
  REMOTE_ENABLED_KEY: () => REMOTE_ENABLED_KEY,
  REMOTE_TOKEN_KEY: () => REMOTE_TOKEN_KEY,
  getRemoteBridgeUrl: () => getRemoteBridgeUrl,
  getRemoteEnabled: () => getRemoteEnabled,
  getRemoteToken: () => getRemoteToken,
  setRemoteBridgeUrl: () => setRemoteBridgeUrl,
  setRemoteEnabled: () => setRemoteEnabled,
  setRemoteToken: () => setRemoteToken
});
async function getRemoteEnabled() {
  const out = await chrome.storage.local.get(REMOTE_ENABLED_KEY);
  return out[REMOTE_ENABLED_KEY] !== false;
}
async function setRemoteEnabled(v) {
  await chrome.storage.local.set({ [REMOTE_ENABLED_KEY]: v });
}
async function getRemoteBridgeUrl() {
  const out = await chrome.storage.local.get(REMOTE_BRANCH_KEY);
  const v = out[REMOTE_BRANCH_KEY];
  return typeof v === "string" && v ? v : REMOTE_BRIDGE_WSS;
}
async function setRemoteBridgeUrl(u) {
  await chrome.storage.local.set({ [REMOTE_BRANCH_KEY]: u.trim() });
}
async function getRemoteToken() {
  const out = await chrome.storage.local.get(REMOTE_TOKEN_KEY);
  return typeof out[REMOTE_TOKEN_KEY] === "string" ? out[REMOTE_TOKEN_KEY] : "";
}
async function setRemoteToken(t) {
  await chrome.storage.local.set({ [REMOTE_TOKEN_KEY]: t.trim() });
}
var REMOTE_BRIDGE_WSS, REMOTE_BRIDGE_HOST, REMOTE_TOKEN_KEY, REMOTE_ENABLED_KEY, REMOTE_BRANCH_KEY;
var init_remote_store = __esm({
  "src/remote-store.ts"() {
    "use strict";
    REMOTE_BRIDGE_WSS = "wss://capture.eemaill.codes/bridge/ws";
    REMOTE_BRIDGE_HOST = "capture.eemaill.codes";
    REMOTE_TOKEN_KEY = "remoteBridgeToken";
    REMOTE_ENABLED_KEY = "remoteEnabled";
    REMOTE_BRANCH_KEY = "remoteBridgeUrl";
  }
});

// ../shared/src/captcha-detector.ts
var matchers = [
  // reCAPTCHA Enterprise
  {
    test: (u) => {
      if (!isGoogleRecaptchaHost(u.hostname)) return null;
      if (!u.pathname.includes("/recaptcha/enterprise/")) return null;
      const k = u.searchParams.get("k");
      if (!k) return null;
      const extra = {};
      const co = u.searchParams.get("co");
      if (co) extra.co = co;
      return {
        type: "recaptcha-enterprise",
        sitekey: k,
        extra: Object.keys(extra).length ? extra : void 0
      };
    }
  },
  // reCAPTCHA script load: /recaptcha/enterprise.js?render=<sitekey>
  {
    test: (u) => {
      if (!isGoogleRecaptchaHost(u.hostname)) return null;
      if (!u.pathname.startsWith("/recaptcha/enterprise.js")) return null;
      const k = u.searchParams.get("render");
      if (!k) return null;
      return { type: "recaptcha-enterprise", sitekey: k };
    }
  },
  // reCAPTCHA v2 / v3 (api2)
  {
    test: (u) => {
      if (!isGoogleRecaptchaHost(u.hostname)) return null;
      if (!u.pathname.startsWith("/recaptcha/api2/")) return null;
      const k = u.searchParams.get("k");
      if (!k) return null;
      const size = u.searchParams.get("size") ?? "";
      const type = size === "invisible" || u.pathname.includes("/reload") || u.pathname.includes("/userverify") ? "recaptcha-v3" : "recaptcha-v2";
      const extra = {};
      const co = u.searchParams.get("co");
      if (co) extra.co = co;
      return { type, sitekey: k, extra: Object.keys(extra).length ? extra : void 0 };
    }
  },
  // reCAPTCHA script load: /recaptcha/api.js?render=<sitekey>
  {
    test: (u) => {
      if (!isGoogleRecaptchaHost(u.hostname)) return null;
      if (!u.pathname.startsWith("/recaptcha/api.js")) return null;
      const k = u.searchParams.get("render");
      if (!k) return null;
      if (k === "explicit") return null;
      return { type: "recaptcha-v3", sitekey: k };
    }
  },
  // hCaptcha
  {
    test: (u) => {
      if (!u.hostname.endsWith("hcaptcha.com")) return null;
      const mGet = u.pathname.match(/\/getcaptcha\/([^/?]+)/);
      if (mGet) return { type: "hcaptcha", sitekey: mGet[1] };
      const mChk = u.pathname.match(/\/checkcaptcha\/([^/?]+)/);
      if (mChk) return { type: "hcaptcha", sitekey: mChk[1] };
      const sk = u.searchParams.get("sitekey");
      if (sk) return { type: "hcaptcha", sitekey: sk };
      return null;
    }
  },
  // Cloudflare Turnstile
  {
    test: (u) => {
      if (!u.hostname.endsWith("challenges.cloudflare.com")) return null;
      const sk = u.searchParams.get("sitekey");
      if (sk) return { type: "turnstile", sitekey: sk };
      const mk = u.pathname.match(/\/turnstile\/v0\/[a-z0-9]+\/([A-Za-z0-9_-]{8,})/);
      if (mk) return { type: "turnstile", sitekey: mk[1] };
      return { type: "turnstile", sitekey: "" };
    }
  },
  // Arkose Labs / FunCaptcha
  {
    test: (u) => {
      const h = u.hostname;
      if (!(h.endsWith("arkoselabs.com") || h.endsWith("funcaptcha.com") || h.endsWith("arkose-labs.com")))
        return null;
      const mPath = u.pathname.match(/\/v2\/([0-9A-F-]{8,})\b/i);
      if (mPath) return { type: "arkose", sitekey: mPath[1] };
      const pk = u.searchParams.get("public_key") || u.searchParams.get("publickey") || u.searchParams.get("key") || u.searchParams.get("pkey");
      if (pk) return { type: "arkose", sitekey: pk };
      return { type: "arkose", sitekey: "" };
    }
  },
  // GeeTest v3 / v4
  {
    test: (u) => {
      const h = u.hostname;
      if (!(h.endsWith("geetest.com") || h.endsWith("geevisit.com"))) return null;
      const gt = u.searchParams.get("gt") ?? "";
      const challenge = u.searchParams.get("challenge") ?? "";
      const captchaId = u.searchParams.get("captcha_id") ?? "";
      if (captchaId && !gt) {
        return { type: "geetest-v4", sitekey: captchaId };
      }
      if (gt) {
        return {
          type: "geetest",
          sitekey: gt,
          extra: challenge ? { challenge } : void 0
        };
      }
      return null;
    }
  },
  // DataDome
  {
    test: (u) => {
      const h = u.hostname;
      if (h.endsWith("captcha-delivery.com") || h.endsWith("datadome.co") || h.endsWith("datado.me")) {
        const cid = u.searchParams.get("cid") ?? u.searchParams.get("initialCid") ?? "";
        return { type: "datadome", sitekey: "", extra: cid ? { cid } : void 0 };
      }
      return null;
    }
  },
  // AWS WAF Captcha
  {
    test: (u) => {
      const h = u.hostname;
      if (h.endsWith("awswaf.com") || h.endsWith("captcha-prod.awswaf.com")) {
        return { type: "aws-waf", sitekey: "" };
      }
      return null;
    }
  }
];
function isGoogleRecaptchaHost(h) {
  return h === "www.google.com" || h === "google.com" || h === "www.recaptcha.net" || h === "recaptcha.net";
}
function detectFromUrl(input) {
  let parsed;
  try {
    parsed = new URL(input.url);
  } catch {
    return null;
  }
  for (const m of matchers) {
    const hit = m.test(parsed, input.url, input.requestBody);
    if (hit) {
      return {
        id: stableId(hit.type, hit.sitekey, input.pageHost),
        type: hit.type,
        sitekey: hit.sitekey,
        pageUrl: input.pageUrl,
        pageHost: input.pageHost,
        sourceUrl: input.url,
        source: "network",
        detectedAt: Date.now(),
        tabId: input.tabId,
        requestId: input.requestId,
        extra: hit.extra
      };
    }
  }
  return null;
}
function stableId(type, sitekey, pageHost) {
  const s = `${type}|${sitekey}|${pageHost}`;
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = h * 33 ^ s.charCodeAt(i);
  return (h >>> 0).toString(36);
}

// ../shared/src/index.ts
var BRIDGE_PORT = 9876;
var BRIDGE_HOST = "127.0.0.1";
var PROTOCOL_VERSION = 2;
var CDP_RESOURCE_TYPES = /* @__PURE__ */ new Set([
  "Document",
  "Stylesheet",
  "Image",
  "Media",
  "Font",
  "Script",
  "TextTrack",
  "XHR",
  "Fetch",
  "Prefetch",
  "EventSource",
  "WebSocket",
  "Manifest",
  "SignedExchange",
  "Ping",
  "CSPViolationReport",
  "Preflight",
  "FedCM",
  "Other"
]);
function mapResourceTypeFull(t) {
  return CDP_RESOURCE_TYPES.has(t) ? t : "Other";
}
var DATA_DENYLIST = /* @__PURE__ */ new Set([
  "Image",
  "Stylesheet",
  "Font",
  "Media",
  "TextTrack",
  "Prefetch"
]);
function shouldCapture(type, scope) {
  if (scope === "all") return true;
  return !DATA_DENYLIST.has(type);
}
function hostMatchesAllowlist(host, allowlist) {
  if (!host) return false;
  const h = host.toLowerCase();
  return allowlist.some((d) => {
    if (!d) return false;
    if (d === h) return true;
    return h.endsWith("." + d);
  });
}
function cdpDuration(input) {
  const durationMs = Math.max(0, input.endMonotonicSec - input.startMonotonicSec) * 1e3;
  const endedAt = input.startedAtEpochMs + durationMs;
  return { durationMs, endedAt };
}
var MAX_WS_MESSAGES = 5e3;
function pushBounded(arr, item, max) {
  arr.push(item);
  if (arr.length > max) arr.splice(0, arr.length - max);
  return arr;
}
function pickEvictionKey(entries) {
  for (const e of entries) if (e.type !== "WebSocket") return e.key;
  return void 0;
}

// src/bridge.ts
var RECONNECT_MS = 2e3;
var AUTH_TIMEOUT_MS = 5e3;
var Bridge = class {
  ws = null;
  queue = [];
  handlers = [];
  authHandlers = [];
  connectTimer = null;
  getToken;
  getUrl;
  authed = false;
  authTimer = null;
  keepAliveTimer = null;
  usePolling = false;
  allowPolling;
  constructor(getToken2, getUrl, opts) {
    this.getToken = getToken2;
    this.getUrl = getUrl || (() => `ws://${BRIDGE_HOST}:${BRIDGE_PORT}`);
    this.allowPolling = opts?.allowPolling ?? false;
  }
  start() {
    this.connect();
  }
  onMessage(fn) {
    this.handlers.push(fn);
  }
  onAuthenticated(fn) {
    this.authHandlers.push(fn);
  }
  send(msg) {
    if (this.usePolling) {
      this.sendViaHttp(msg);
      return;
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN && this.authed) {
      try {
        this.ws.send(JSON.stringify(msg));
      } catch (e) {
        console.warn("[bridge] send failed", e);
        this.queue.push(msg);
      }
    } else {
      if (this.queue.length < 2e3) this.queue.push(msg);
    }
  }
  isOpen() {
    if (this.usePolling) return this.authed;
    return this.authed && this.ws?.readyState === WebSocket.OPEN;
  }
  forceReconnect() {
    this.stopPolling();
    const old = this.ws;
    this.ws = null;
    this.authed = false;
    this.usePolling = false;
    if (this.authTimer != null) {
      clearTimeout(this.authTimer);
      this.authTimer = null;
    }
    if (old) {
      try {
        old.close();
      } catch {
      }
    }
    this.connect();
  }
  async connect() {
    if (this.ws || this.usePolling) return;
    const url = this.getUrl();
    let socket;
    try {
      socket = new WebSocket(url);
    } catch (e) {
      console.warn("[bridge] cannot open", url, e);
      if (this.allowPolling) this.fallbackToPolling();
      else this.scheduleReconnect();
      return;
    }
    this.ws = socket;
    const openTimeout = this.allowPolling ? self.setTimeout(() => {
      if (this.ws === socket && !this.authed) {
        console.warn("[bridge] ws open timeout, falling back to HTTP polling");
        try {
          socket.close();
        } catch {
        }
        this.ws = null;
        this.fallbackToPolling();
      }
    }, 5e3) : null;
    socket.addEventListener("open", async () => {
      if (this.ws !== socket) return;
      if (openTimeout != null) clearTimeout(openTimeout);
      const token = await this.getToken();
      const auth = {
        kind: "auth",
        token,
        extensionVersion: chrome.runtime.getManifest().version,
        protocol: PROTOCOL_VERSION
      };
      try {
        socket.send(JSON.stringify(auth));
      } catch {
      }
      this.authTimer = self.setTimeout(() => {
        if (this.ws === socket && !this.authed) {
          console.warn("[bridge] auth timeout");
          try {
            socket.close();
          } catch {
          }
        }
      }, AUTH_TIMEOUT_MS);
    });
    socket.addEventListener("message", (ev) => {
      if (this.ws !== socket) return;
      try {
        const parsed = JSON.parse(ev.data);
        if (parsed.kind === "auth-ok") {
          this.authed = true;
          if (this.authTimer != null) {
            clearTimeout(this.authTimer);
            this.authTimer = null;
          }
          console.log("[bridge] authenticated", url);
          this.startKeepAlive();
          const drain = this.queue.splice(0);
          for (const m of drain) this.send(m);
          for (const fn of this.authHandlers) {
            try {
              fn();
            } catch (e) {
              console.warn("[bridge] auth handler threw", e);
            }
          }
          return;
        }
        if (parsed.kind === "auth-fail") {
          console.warn("[bridge] auth failed:", parsed.reason);
          try {
            socket.close();
          } catch {
          }
          return;
        }
        for (const h of this.handlers) h(parsed);
      } catch (e) {
        console.warn("[bridge] bad message", e);
      }
    });
    socket.addEventListener("close", () => {
      this.stopKeepAlive();
      if (this.ws === socket) {
        this.ws = null;
        this.authed = false;
        if (this.authTimer != null) {
          clearTimeout(this.authTimer);
          this.authTimer = null;
        }
        this.scheduleReconnect();
      }
    });
    socket.addEventListener("error", () => {
      try {
        socket.close();
      } catch {
      }
    });
  }
  async fallbackToPolling() {
    if (!this.allowPolling || this.usePolling) return;
    this.usePolling = true;
    const url = this.getUrl();
    const serverUrl = url.replace(/^wss?:\/\//, "https://").replace(/\/bridge\/ws$/, "");
    const token = await this.getToken();
    console.log("[bridge] using HTTP polling to", serverUrl);
    try {
      const resp = await fetch(`${serverUrl}/api/bridge/poll?token=${encodeURIComponent(token)}`);
      if (!resp.ok) {
        console.warn("[bridge] HTTP poll auth failed");
        this.usePolling = false;
        this.scheduleReconnect();
        return;
      }
    } catch (e) {
      console.warn("[bridge] HTTP poll failed", e);
      this.usePolling = false;
      this.scheduleReconnect();
      return;
    }
    this.authed = true;
    console.log("[bridge] HTTP polling authenticated");
    for (const fn of this.authHandlers) {
      try {
        fn();
      } catch {
      }
    }
    const drain = this.queue.splice(0);
    for (const m of drain) this.sendViaHttp(m);
  }
  async sendViaHttp(msg) {
    const url = this.getUrl();
    const serverUrl = url.replace(/^wss?:\/\//, "https://").replace(/\/bridge\/ws$/, "");
    const token = await this.getToken();
    try {
      await fetch(`${serverUrl}/api/bridge/send`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...msg, token })
      });
    } catch (e) {
      console.warn("[bridge] HTTP send failed", e);
      if (this.queue.length < 2e3) this.queue.push(msg);
    }
  }
  stopPolling() {
    this.usePolling = false;
  }
  scheduleReconnect() {
    if (this.connectTimer != null) return;
    this.connectTimer = self.setTimeout(() => {
      this.connectTimer = null;
      this.connect();
    }, RECONNECT_MS);
  }
  startKeepAlive() {
    this.stopKeepAlive();
    this.keepAliveTimer = self.setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          this.ws.send(JSON.stringify({ kind: "ping" }));
        } catch {
        }
      }
    }, 25e3);
  }
  stopKeepAlive() {
    if (this.keepAliveTimer != null) {
      clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }
  }
};

// src/debugger.ts
var DEBUGGER_PROTOCOL = "1.3";
var WAIT_FOR_DEBUGGER = true;
var CHILD_FILTER = [
  { type: "iframe" },
  { type: "worker" },
  { type: "shared_worker" },
  { type: "service_worker" }
];
var INFLIGHT_LIMIT = 2e3;
function headersToList(headers) {
  if (!headers) return [];
  return Object.entries(headers).map(([name, value]) => ({ name, value: String(value) }));
}
function parseHost(url) {
  try {
    return new URL(url).host;
  } catch {
    return "";
  }
}
var DebuggerCapture = class {
  attachedTabs = /* @__PURE__ */ new Set();
  // Synchronous reservation set (Bug 2). A tab is added here BEFORE the
  // `await chrome.debugger.attach` so a concurrent redundant attach() on the same
  // navigation hits the guard and returns without touching live state. Released in
  // the owning attempt's `finally`. Mirrors the pure AttachRegistry `attaching` set.
  attaching = /* @__PURE__ */ new Set();
  // sessionId -> child session info. Root sessions have no sessionId and are
  // represented by tabId only (not stored here).
  sessions = /* @__PURE__ */ new Map();
  // tabId -> set of child sessionIds, for O(1) teardown when a tab detaches.
  tabSessions = /* @__PURE__ */ new Map();
  inFlight = /* @__PURE__ */ new Map();
  listener;
  getScope;
  constructor(listener, getScope) {
    this.listener = listener;
    this.getScope = getScope;
    chrome.debugger.onEvent.addListener(this.handleEvent);
    chrome.debugger.onDetach.addListener(this.handleDetach);
  }
  async attach(tabId) {
    if (this.attachedTabs.has(tabId) || this.attaching.has(tabId)) return;
    this.attaching.add(tabId);
    try {
      await chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL);
      this.attachedTabs.add(tabId);
      this.tabSessions.set(tabId, /* @__PURE__ */ new Set());
      await chrome.debugger.sendCommand({ tabId }, "Network.enable", {
        maxResourceBufferSize: 10 * 1024 * 1024,
        maxTotalBufferSize: 50 * 1024 * 1024
      });
      await chrome.debugger.sendCommand({ tabId }, "Target.setAutoAttach", {
        autoAttach: true,
        waitForDebuggerOnStart: WAIT_FOR_DEBUGGER,
        flatten: true,
        filter: CHILD_FILTER
      });
      console.log("[debugger] attached", tabId);
    } catch (e) {
      console.warn("[debugger] attach failed", tabId, e);
      this.attachedTabs.delete(tabId);
      this.tabSessions.delete(tabId);
    } finally {
      this.attaching.delete(tabId);
    }
  }
  async detach(tabId) {
    if (!this.attachedTabs.has(tabId)) return;
    try {
      await chrome.debugger.detach({ tabId });
    } catch (e) {
      console.warn("[debugger] detach failed", tabId, e);
    }
    this.cleanupTab(tabId);
  }
  async detachAll() {
    const ids = Array.from(this.attachedTabs);
    for (const id of ids) await this.detach(id);
  }
  isAttached(tabId) {
    return this.attachedTabs.has(tabId);
  }
  attachedCount() {
    return this.attachedTabs.size;
  }
  // ───────────────────── child-target lifecycle ─────────────────────
  async onAttachedToTarget(source, p) {
    const sessionId = p.sessionId;
    const info = p.targetInfo;
    const waiting = !!p.waitingForDebugger;
    const childTarget = { sessionId };
    const parentTabId = source.tabId ?? (source.sessionId ? this.sessions.get(source.sessionId)?.tabId : void 0);
    if (parentTabId == null) {
      await this.safeResume(childTarget, waiting);
      return;
    }
    if (this.sessions.has(sessionId)) {
      await this.safeResume(childTarget, waiting);
      return;
    }
    this.sessions.set(sessionId, {
      sessionId,
      tabId: parentTabId,
      target: childTarget,
      targetType: info?.type ?? "other"
    });
    this.tabSessions.get(parentTabId)?.add(sessionId);
    try {
      await chrome.debugger.sendCommand(childTarget, "Network.enable", {});
      await chrome.debugger.sendCommand(childTarget, "Target.setAutoAttach", {
        autoAttach: true,
        waitForDebuggerOnStart: WAIT_FOR_DEBUGGER,
        flatten: true,
        filter: CHILD_FILTER
      });
    } catch (e) {
      console.warn("[debugger] child setup failed", sessionId, e);
    } finally {
      await this.safeResume(childTarget, waiting);
    }
  }
  async safeResume(target, waiting) {
    if (!waiting) return;
    try {
      await chrome.debugger.sendCommand(target, "Runtime.runIfWaitingForDebugger", {});
    } catch {
    }
  }
  onDetachedFromTarget(p) {
    const sessionId = p.sessionId;
    const info = this.sessions.get(sessionId);
    if (!info) return;
    this.sessions.delete(sessionId);
    this.tabSessions.get(info.tabId)?.delete(sessionId);
    this.dropInFlightForSession(sessionId);
  }
  cleanupTab(tabId) {
    this.attachedTabs.delete(tabId);
    const sids = this.tabSessions.get(tabId);
    if (sids) {
      for (const sid of sids) {
        this.sessions.delete(sid);
        this.dropInFlightForSession(sid);
      }
    }
    this.tabSessions.delete(tabId);
    for (const [k, f] of this.inFlight) {
      if (f.tabId === tabId && k.startsWith(":")) this.inFlight.delete(k);
    }
  }
  dropInFlightForSession(sessionId) {
    const prefix = `${sessionId}:`;
    for (const k of this.inFlight.keys()) if (k.startsWith(prefix)) this.inFlight.delete(k);
  }
  // ───────────────────── event routing ─────────────────────
  handleDetach = (source, reason) => {
    if (source.tabId != null) {
      this.cleanupTab(source.tabId);
      console.log("[debugger] detached", source.tabId, reason);
    }
  };
  handleEvent = (source, method, params) => {
    if (method === "Target.attachedToTarget") {
      void this.onAttachedToTarget(source, params);
      return;
    }
    if (method === "Target.detachedFromTarget") {
      this.onDetachedFromTarget(params);
      return;
    }
    const sessionId = source.sessionId;
    let tabId;
    let sessionTarget;
    if (sessionId) {
      const info = this.sessions.get(sessionId);
      if (!info) return;
      tabId = info.tabId;
      sessionTarget = info.target;
    } else {
      if (source.tabId == null) return;
      tabId = source.tabId;
      sessionTarget = { tabId: source.tabId };
    }
    switch (method) {
      case "Network.requestWillBeSent":
        this.onRequestWillBeSent(tabId, sessionId, sessionTarget, params);
        break;
      case "Network.responseReceived":
        this.onResponseReceived(sessionId, params);
        break;
      case "Network.loadingFinished":
        void this.onLoadingFinished(sessionId, params);
        break;
      case "Network.loadingFailed":
        this.onLoadingFailed(sessionId, params);
        break;
      case "Network.webSocketCreated":
        this.onWebSocketCreated(tabId, sessionId, sessionTarget, params);
        break;
      case "Network.webSocketWillSendHandshakeRequest":
        this.onWebSocketWillSendHandshakeRequest(sessionId, params);
        break;
      case "Network.webSocketFrameSent":
        this.onWebSocketFrame(sessionId, params, "sent");
        break;
      case "Network.webSocketFrameReceived":
        this.onWebSocketFrame(sessionId, params, "received");
        break;
      case "Network.webSocketClosed":
        this.onWebSocketClosed(sessionId, params);
        break;
    }
  };
  keyFor(sessionId, requestId) {
    return `${sessionId ?? ""}:${requestId}`;
  }
  trackInFlight(f) {
    this.inFlight.set(f.key, f);
    if (this.inFlight.size > INFLIGHT_LIMIT) {
      const victim = pickEvictionKey(this.inFlight.values());
      if (victim !== void 0) this.inFlight.delete(victim);
    }
  }
  onRequestWillBeSent(tabId, sessionId, target, p) {
    const reqId = p.requestId;
    try {
      this.listener.onCaptchaUrl?.(
        p.request.url,
        tabId,
        reqId,
        typeof p.request.postData === "string" ? p.request.postData : void 0
      );
    } catch {
    }
    const rt = mapResourceTypeFull(p.type);
    if (!shouldCapture(rt, this.getScope())) return;
    const key = this.keyFor(sessionId, reqId);
    if (p.redirectResponse) {
      const existing = this.inFlight.get(key);
      if (existing) {
        this.listener.onUpdate(existing.id, {
          status: p.redirectResponse.status,
          statusText: p.redirectResponse.statusText
        });
      }
    }
    const startedAt = (p.wallTime ?? Date.now() / 1e3) * 1e3;
    const startMonotonicSec = typeof p.timestamp === "number" ? p.timestamp : void 0;
    const id = key;
    const inflight = {
      id,
      key,
      tabId,
      sessionTarget: target,
      type: rt,
      method: p.request.method,
      url: p.request.url,
      host: parseHost(p.request.url),
      startedAt,
      startMonotonicSec,
      requestHeaders: headersToList(p.request.headers),
      requestBody: typeof p.request.postData === "string" ? p.request.postData : void 0,
      initiator: p.initiator?.type
    };
    this.trackInFlight(inflight);
    this.listener.onRequest({
      id,
      tabId,
      type: rt,
      method: inflight.method,
      url: inflight.url,
      host: inflight.host,
      startedAt,
      requestHeaders: inflight.requestHeaders,
      requestBody: inflight.requestBody,
      responseHeaders: [],
      initiator: inflight.initiator
    });
  }
  onResponseReceived(sessionId, p) {
    const f = this.inFlight.get(this.keyFor(sessionId, p.requestId));
    if (!f) return;
    const r = p.response;
    this.listener.onUpdate(f.id, {
      status: r.status,
      statusText: r.statusText,
      responseHeaders: headersToList(r.headers),
      responseMimeType: r.mimeType,
      fromCache: !!r.fromDiskCache
    });
  }
  async onLoadingFinished(sessionId, p) {
    const key = this.keyFor(sessionId, p.requestId);
    const f = this.inFlight.get(key);
    if (!f) return;
    const timing = f.startMonotonicSec != null && typeof p.timestamp === "number" ? cdpDuration({
      startedAtEpochMs: f.startedAt,
      startMonotonicSec: f.startMonotonicSec,
      endMonotonicSec: p.timestamp
    }) : (() => {
      const now = Date.now();
      return { endedAt: now, durationMs: Math.max(0, now - f.startedAt) };
    })();
    let body;
    let isBase64 = false;
    try {
      const r = await chrome.debugger.sendCommand(f.sessionTarget, "Network.getResponseBody", {
        requestId: p.requestId
      });
      if (r) {
        body = r.body;
        isBase64 = !!r.base64Encoded;
      }
    } catch {
    }
    this.listener.onUpdate(f.id, {
      endedAt: timing.endedAt,
      durationMs: timing.durationMs,
      responseBody: body,
      responseSize: typeof p.encodedDataLength === "number" ? p.encodedDataLength : void 0,
      // Bug 4: flag base64 separately instead of overwriting responseMimeType. The real
      // content-type set by onResponseReceived (from r.mimeType) is preserved; har.ts reads
      // responseBodyBase64 to set content.encoding while keeping the true mimeType.
      ...isBase64 ? { responseBodyBase64: true } : {}
    });
    this.inFlight.delete(key);
  }
  onLoadingFailed(sessionId, p) {
    const key = this.keyFor(sessionId, p.requestId);
    const f = this.inFlight.get(key);
    if (!f) return;
    const timing = f.startMonotonicSec != null && typeof p.timestamp === "number" ? cdpDuration({
      startedAtEpochMs: f.startedAt,
      startMonotonicSec: f.startMonotonicSec,
      endMonotonicSec: p.timestamp
    }) : (() => {
      const now = Date.now();
      return { endedAt: now, durationMs: Math.max(0, now - f.startedAt) };
    })();
    this.listener.onUpdate(f.id, {
      failed: true,
      errorText: p.errorText,
      endedAt: timing.endedAt,
      durationMs: timing.durationMs
    });
    this.inFlight.delete(key);
  }
  onWebSocketCreated(tabId, sessionId, target, p) {
    const reqId = p.requestId;
    const url = p.url;
    const startedAt = Date.now();
    const key = this.keyFor(sessionId, reqId);
    const id = key;
    const inflight = {
      id,
      key,
      tabId,
      sessionTarget: target,
      type: "WebSocket",
      method: "GET",
      url,
      host: parseHost(url),
      startedAt,
      requestHeaders: [],
      initiator: p.initiator?.type
    };
    this.trackInFlight(inflight);
    this.listener.onRequest({
      id,
      tabId,
      type: "WebSocket",
      method: "GET",
      url,
      host: inflight.host,
      startedAt,
      requestHeaders: [],
      responseHeaders: [],
      wsMessages: [],
      initiator: inflight.initiator
    });
  }
  onWebSocketWillSendHandshakeRequest(sessionId, p) {
    const f = this.inFlight.get(this.keyFor(sessionId, p.requestId));
    if (!f) return;
    if (typeof p.timestamp === "number") f.startMonotonicSec = p.timestamp;
    if (typeof p.wallTime === "number") f.startedAt = p.wallTime * 1e3;
  }
  onWebSocketFrame(sessionId, p, direction) {
    const f = this.inFlight.get(this.keyFor(sessionId, p.requestId));
    if (!f) return;
    const r = p.response ?? {};
    const payload = typeof r.payloadData === "string" ? r.payloadData : "";
    const frameEpochMs = f.startMonotonicSec != null && typeof p.timestamp === "number" ? cdpDuration({
      startedAtEpochMs: f.startedAt,
      startMonotonicSec: f.startMonotonicSec,
      endMonotonicSec: p.timestamp
    }).endedAt : Date.now();
    const opcode = typeof r.opcode === "number" ? r.opcode : 0;
    const msg = {
      direction,
      timestamp: frameEpochMs,
      opcode,
      payload,
      payloadLength: payload.length,
      // Bug 4: mark binary frames (opcode 2) explicitly so har.ts can flag encoding='base64'
      // downstream rather than inferring it solely from the opcode.
      ...opcode === 2 ? { isBinary: true } : {}
    };
    this.listener.onWsMessage(f.id, msg);
  }
  onWebSocketClosed(sessionId, p) {
    const key = this.keyFor(sessionId, p.requestId);
    const f = this.inFlight.get(key);
    if (!f) return;
    const timing = f.startMonotonicSec != null && typeof p.timestamp === "number" ? cdpDuration({
      startedAtEpochMs: f.startedAt,
      startMonotonicSec: f.startMonotonicSec,
      endMonotonicSec: p.timestamp
    }) : (() => {
      const now = Date.now();
      return { endedAt: now, durationMs: Math.max(0, now - f.startedAt) };
    })();
    this.listener.onUpdate(f.id, {
      endedAt: timing.endedAt,
      durationMs: timing.durationMs
    });
    this.inFlight.delete(key);
  }
};

// src/store.ts
var ALLOWLIST_KEY = "allowlist";
var CAPTURE_ENABLED_KEY = "captureEnabled";
var CAPTURE_SCOPE_KEY = "captureScope";
var TOKEN_KEY = "bridgeToken";
var RECENT_HOSTS_KEY = "recentHosts";
var STICKY_TABS_KEY = "stickyTabs";
var RECENT_LIMIT = 30;
async function getAllowlist() {
  const out = await chrome.storage.local.get(ALLOWLIST_KEY);
  const v = out[ALLOWLIST_KEY];
  return Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
}
async function setAllowlist(domains) {
  const clean = Array.from(new Set(domains.map((d) => d.trim().toLowerCase()).filter(Boolean)));
  await chrome.storage.local.set({ [ALLOWLIST_KEY]: clean });
}
async function getCaptureEnabled() {
  const out = await chrome.storage.local.get(CAPTURE_ENABLED_KEY);
  return out[CAPTURE_ENABLED_KEY] !== false;
}
async function setCaptureEnabled(enabled) {
  await chrome.storage.local.set({ [CAPTURE_ENABLED_KEY]: enabled });
}
async function getCaptureScope() {
  const out = await chrome.storage.local.get(CAPTURE_SCOPE_KEY);
  return out[CAPTURE_SCOPE_KEY] === "all" ? "all" : "data";
}
async function setCaptureScope(scope) {
  await chrome.storage.local.set({ [CAPTURE_SCOPE_KEY]: scope === "all" ? "all" : "data" });
}
async function getStickyTabs() {
  try {
    const out = await chrome.storage.session.get(STICKY_TABS_KEY);
    const v = out[STICKY_TABS_KEY];
    return Array.isArray(v) ? v.filter((x) => typeof x === "number") : [];
  } catch {
    return [];
  }
}
async function setStickyTabs(tabIds) {
  try {
    await chrome.storage.session.set({ [STICKY_TABS_KEY]: tabIds });
  } catch {
  }
}
async function getToken() {
  const out = await chrome.storage.local.get(TOKEN_KEY);
  return typeof out[TOKEN_KEY] === "string" ? out[TOKEN_KEY] : "";
}
async function setToken(token) {
  await chrome.storage.local.set({ [TOKEN_KEY]: token.trim() });
}
async function getRecentHosts() {
  const out = await chrome.storage.local.get(RECENT_HOSTS_KEY);
  const v = out[RECENT_HOSTS_KEY];
  return Array.isArray(v) ? v : [];
}
async function recordHost(host) {
  if (!host) return;
  const list = await getRecentHosts();
  const now = Date.now();
  const idx = list.findIndex((e) => e.host === host);
  if (idx >= 0) {
    list[idx].count += 1;
    list[idx].last = now;
  } else {
    list.push({ host, count: 1, last: now });
  }
  list.sort((a, b) => b.last - a.last);
  await chrome.storage.local.set({ [RECENT_HOSTS_KEY]: list.slice(0, RECENT_LIMIT) });
}
async function clearRecentHosts() {
  await chrome.storage.local.set({ [RECENT_HOSTS_KEY]: [] });
}

// src/background.ts
init_remote_store();

// src/webrequest-fallback.ts
var TYPE_MAP = {
  main_frame: "Document",
  sub_frame: "Document",
  xmlhttprequest: "XHR",
  fetch: "Fetch",
  websocket: "WebSocket",
  script: "Script",
  stylesheet: "Stylesheet",
  image: "Image",
  font: "Font",
  media: "Media",
  ping: "Ping",
  other: "Other"
};
var WebRequestFallback = class {
  enabled = false;
  inflight = /* @__PURE__ */ new Map();
  handlers;
  getters;
  bound = false;
  constructor(handlers, getters) {
    this.handlers = handlers;
    this.getters = getters;
  }
  start() {
    if (this.bound || !chrome.webRequest) return;
    this.bound = true;
    this.enabled = true;
    chrome.webRequest.onBeforeRequest.addListener(
      (details) => {
        void this.onBeforeRequest(details);
      },
      { urls: ["<all_urls>"] },
      ["requestBody"]
    );
    chrome.webRequest.onSendHeaders.addListener(
      (details) => {
        void this.onSendHeaders(details);
      },
      { urls: ["<all_urls>"] },
      ["requestHeaders", "extraHeaders"]
    );
    chrome.webRequest.onHeadersReceived.addListener(
      (details) => {
        void this.onHeadersReceived(details);
      },
      { urls: ["<all_urls>"] },
      ["responseHeaders", "extraHeaders"]
    );
    chrome.webRequest.onCompleted.addListener(
      (details) => {
        void this.onCompleted(details);
      },
      { urls: ["<all_urls>"] }
    );
    chrome.webRequest.onErrorOccurred.addListener(
      (details) => {
        void this.onError(details);
      },
      { urls: ["<all_urls>"] }
    );
  }
  stop() {
    this.enabled = false;
  }
  key(details) {
    return `wr:${details.tabId}:${details.requestId}`;
  }
  async allowed(details) {
    if (!this.enabled) return false;
    if (details.tabId >= 0 && this.getters.isDebuggerAttached(details.tabId)) return false;
    const enabled = await this.getters.getCaptureEnabled();
    if (!enabled) return false;
    let host = "";
    try {
      host = new URL(details.url).host;
    } catch {
      return false;
    }
    const allowlist = await this.getters.getAllowlist();
    const sticky = details.tabId >= 0 && this.getters.isSticky(details.tabId);
    if (!sticky && allowlist.length > 0 && !hostMatchesAllowlist(host, allowlist)) return false;
    const type = mapResourceTypeFull(TYPE_MAP[details.type] || "Other");
    if (!shouldCapture(type, this.getters.getScope())) return false;
    return true;
  }
  async onBeforeRequest(details) {
    if (!await this.allowed(details)) return;
    const type = mapResourceTypeFull(TYPE_MAP[details.type] || "Other");
    let host = "";
    try {
      host = new URL(details.url).host;
    } catch {
    }
    let requestBody;
    try {
      const rb = details.requestBody;
      if (rb?.raw?.[0]?.bytes) {
        requestBody = new TextDecoder().decode(new Uint8Array(rb.raw[0].bytes)).slice(0, 2e5);
      } else if (rb?.formData) {
        requestBody = JSON.stringify(rb.formData).slice(0, 2e5);
      }
    } catch {
    }
    const req = {
      id: this.key(details),
      tabId: details.tabId,
      source: "web",
      type,
      method: (details.method || "GET").toUpperCase(),
      url: details.url,
      host,
      startedAt: Date.now(),
      requestHeaders: [],
      responseHeaders: [],
      requestBody,
      initiator: "webRequest-fallback"
    };
    this.inflight.set(req.id, req);
    this.handlers.onRequest(req);
  }
  async onSendHeaders(details) {
    const id = this.key(details);
    const cur = this.inflight.get(id);
    if (!cur) return;
    const headers = (details.requestHeaders || []).map((h) => ({
      name: h.name,
      value: String(h.value || "")
    }));
    cur.requestHeaders = headers;
    this.handlers.onUpdate(id, { requestHeaders: headers });
  }
  async onHeadersReceived(details) {
    const id = this.key(details);
    const cur = this.inflight.get(id);
    if (!cur) return;
    const headers = (details.responseHeaders || []).map((h) => ({
      name: h.name,
      value: String(h.value || "").slice(0, 2e3)
    }));
    const patch = {
      status: details.statusCode,
      responseHeaders: headers
    };
    Object.assign(cur, patch);
    this.handlers.onUpdate(id, patch);
  }
  async onCompleted(details) {
    const id = this.key(details);
    const cur = this.inflight.get(id);
    if (!cur) return;
    const patch = {
      status: details.statusCode,
      endedAt: Date.now(),
      duration: Date.now() - (cur.startedAt || Date.now())
    };
    Object.assign(cur, patch);
    this.handlers.onUpdate(id, patch);
    this.inflight.delete(id);
  }
  async onError(details) {
    const id = this.key(details);
    const cur = this.inflight.get(id);
    if (!cur) return;
    this.handlers.onUpdate(id, {
      status: 0,
      endedAt: Date.now(),
      error: details.error
    });
    this.inflight.delete(id);
  }
};

// src/background.ts
var KEEP_ALIVE_ALARM = "bridge-keepalive";
var localBridge = new Bridge(async () => await getToken());
var remoteUrlCache = "";
var remoteBridge = new Bridge(
  async () => await getRemoteToken(),
  () => remoteUrlCache || "wss://capture.eemaill.codes/bridge/ws",
  { allowPolling: true }
);
getRemoteBridgeUrl().then((u) => {
  remoteUrlCache = u || "wss://capture.eemaill.codes/bridge/ws";
});
chrome.storage.onChanged?.addListener((changes, area) => {
  if (area !== "local") return;
  const b = changes.remoteBridgeUrl?.newValue;
  if (typeof b === "string") remoteUrlCache = b || "wss://capture.eemaill.codes/bridge/ws";
  if (changes.remoteEnabled) {
    if (changes.remoteEnabled.newValue) remoteBridge.start();
  }
  if (changes.remoteBridgeToken || changes.remoteBridgeUrl) {
    remoteBridge.forceReconnect();
  }
});
getRemoteEnabled().then((enabled) => {
  if (enabled !== false) remoteBridge.start();
}).catch(() => remoteBridge.start());
var bridge = {
  start() {
    localBridge.start();
    getRemoteEnabled().then((enabled) => {
      if (enabled !== false) remoteBridge.start();
    }).catch(() => remoteBridge.start());
  },
  onMessage(fn) {
    localBridge.onMessage(fn);
    remoteBridge.onMessage(fn);
  },
  onAuthenticated(fn) {
    let fired = false;
    const wrap = () => {
      if (fired) return;
      fired = true;
      try {
        fn();
      } catch (e) {
        console.warn("[bridge] auth handler threw", e);
      }
    };
    localBridge.onAuthenticated(wrap);
    remoteBridge.onAuthenticated(wrap);
  },
  send(msg) {
    localBridge.send(msg);
    try {
      remoteBridge.send(msg);
    } catch {
    }
  },
  isOpen: () => localBridge.isOpen() || remoteBridge.isOpen(),
  forceReconnect() {
    localBridge.forceReconnect();
    remoteBridge.forceReconnect();
  },
  isLocalOpen: () => localBridge.isOpen(),
  isRemoteOpen: () => remoteBridge.isOpen()
};
var lastCookieSnapshot = /* @__PURE__ */ new Map();
var COOKIE_SNAPSHOT_COOLDOWN = 1e4;
var IMPORTANT_COOKIE_NAMES = /* @__PURE__ */ new Set([
  "xs",
  "c_user",
  "datr",
  "fr",
  "sb",
  "locale",
  "checkpoint",
  "wd",
  "sessionid",
  "auth_token",
  "li_at",
  "csrftoken",
  "session",
  "sid",
  "token"
]);
async function snapshotCookies(url, host) {
  if (!chrome.cookies?.getAll || !host) return;
  const now = Date.now();
  const last = lastCookieSnapshot.get(host) ?? 0;
  if (now - last < COOKIE_SNAPSHOT_COOLDOWN) return;
  lastCookieSnapshot.set(host, now);
  try {
    const cookies = await chrome.cookies.getAll({ url });
    if (!cookies.length) return;
    let important = cookies.filter((c) => IMPORTANT_COOKIE_NAMES.has(c.name));
    if (important.length === 0) important = cookies.slice(0, 30);
    const cookieData = important.map((c) => ({
      name: c.name,
      value: c.value,
      domain: c.domain,
      httpOnly: c.httpOnly,
      secure: c.secure,
      path: c.path
    }));
    bridge.send({ kind: "cookie-snapshot", host, url, cookies: cookieData });
  } catch {
  }
}
if (chrome.webRequest?.onHeadersReceived) {
  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      const setCookies = (details.responseHeaders || []).filter(
        (h) => h.name.toLowerCase() === "set-cookie"
      );
      if (setCookies.length === 0) return;
      const host = (() => {
        try {
          return new URL(details.url).host;
        } catch {
          return "";
        }
      })();
      if (!host) return;
      const cookieData = setCookies.map((h) => (h.value || "").substring(0, 500));
      bridge.send({
        kind: "set-cookie-capture",
        host,
        url: details.url,
        cookies: cookieData
      });
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders", "extraHeaders"]
  );
}
var recentRequests = /* @__PURE__ */ new Map();
var RECENT_LIMIT2 = 500;
var tabPageUrl = /* @__PURE__ */ new Map();
var injectedScanner = /* @__PURE__ */ new Map();
var seenCaptchas = /* @__PURE__ */ new Map();
var SEEN_CAPTCHA_LIMIT = 500;
var CAPTCHA_DEDUPE_MS = 3e4;
var jsDedupe = /* @__PURE__ */ new Map();
var JS_DEDUPE_MS = 1500;
var cdpDedupe = /* @__PURE__ */ new Map();
var REQ_DEDUPE_MS = 1200;
function requestDedupeKey(tabId, method, url) {
  return `${tabId}|${(method || "GET").toUpperCase()}|${url || ""}`;
}
function shouldEmitRequest(tabId, method, url, _source) {
  const key = requestDedupeKey(tabId, method, url);
  const now = Date.now();
  const last = cdpDedupe.get(key) ?? 0;
  if (now - last < REQ_DEDUPE_MS) return false;
  cdpDedupe.set(key, now);
  jsDedupe.set(key, now);
  if (cdpDedupe.size > 3e3) {
    const first = cdpDedupe.keys().next().value;
    if (first) cdpDedupe.delete(first);
  }
  return true;
}
var stickyTabs = /* @__PURE__ */ new Set();
var currentScope = "data";
async function persistSticky() {
  await setStickyTabs(Array.from(stickyTabs));
}
function emitCaptcha(detection) {
  const now = Date.now();
  const last = seenCaptchas.get(detection.id) ?? 0;
  if (now - last < CAPTCHA_DEDUPE_MS) return;
  seenCaptchas.set(detection.id, now);
  if (seenCaptchas.size > SEEN_CAPTCHA_LIMIT) {
    const oldestKey = seenCaptchas.keys().next().value;
    if (oldestKey) seenCaptchas.delete(oldestKey);
  }
  bridge.send({ kind: "captcha-detected", payload: detection });
}
function maybeDetectCaptcha(req) {
  const pageUrl = tabPageUrl.get(req.tabId) ?? "";
  const pageHost = pageUrl ? (() => {
    try {
      return new URL(pageUrl).host;
    } catch {
      return "";
    }
  })() : "";
  const det = detectFromUrl({
    url: req.url,
    pageUrl,
    pageHost: pageHost || req.host,
    requestId: req.id,
    tabId: req.tabId,
    requestBody: req.requestBody
  });
  if (det) emitCaptcha(det);
}
function maybeDetectCaptchaFromUrl(url, tabId, requestId, requestBody) {
  const pageUrl = tabPageUrl.get(tabId) ?? "";
  const pageHost = pageUrl ? (() => {
    try {
      return new URL(pageUrl).host;
    } catch {
      return "";
    }
  })() : "";
  const det = detectFromUrl({
    url,
    pageUrl,
    pageHost,
    requestId,
    tabId,
    requestBody
  });
  if (det) emitCaptcha(det);
}
var capture = new DebuggerCapture(
  {
    onRequest: (req) => {
      if (!shouldEmitRequest(req.tabId, req.method, req.url, "cdp")) return;
      recentRequests.set(req.id, req);
      if (recentRequests.size > RECENT_LIMIT2) {
        const firstKey = recentRequests.keys().next().value;
        if (firstKey) recentRequests.delete(firstKey);
      }
      bridge.send({ kind: "request", payload: req });
      maybeDetectCaptcha(req);
      snapshotCookies(req.url, req.host);
    },
    onUpdate: (id, patch) => {
      const cur = recentRequests.get(id);
      if (cur) Object.assign(cur, patch);
      bridge.send({ kind: "request-update", id, patch });
    },
    onWsMessage: (id, message) => {
      const cur = recentRequests.get(id);
      if (cur) {
        cur.wsMessages = cur.wsMessages ?? [];
        pushBounded(cur.wsMessages, message, MAX_WS_MESSAGES);
      }
      bridge.send({ kind: "ws-message", id, message });
    },
    onCaptchaUrl: (url, tabId, requestId, requestBody) => {
      maybeDetectCaptchaFromUrl(url, tabId, requestId, requestBody);
    }
  },
  () => currentScope
);
var wrFallback = new WebRequestFallback(
  {
    onRequest: (req) => {
      if (!shouldEmitRequest(req.tabId, req.method, req.url, "webRequest")) return;
      recentRequests.set(req.id, req);
      if (recentRequests.size > RECENT_LIMIT2) {
        const firstKey = recentRequests.keys().next().value;
        if (firstKey) recentRequests.delete(firstKey);
      }
      bridge.send({ kind: "request", payload: req });
      maybeDetectCaptcha(req);
      snapshotCookies(req.url, req.host);
    },
    onUpdate: (id, patch) => {
      const cur = recentRequests.get(id);
      if (cur) Object.assign(cur, patch);
      bridge.send({ kind: "request-update", id, patch });
    }
  },
  {
    getScope: () => currentScope,
    getAllowlist,
    getCaptureEnabled,
    isSticky: (tabId) => stickyTabs.has(tabId),
    isDebuggerAttached: (tabId) => capture.isAttached(tabId)
  }
);
wrFallback.start();
function parseHost2(url) {
  if (!url) return "";
  try {
    return new URL(url).host;
  } catch {
    return "";
  }
}
async function syncTabsWithAllowlist() {
  const enabled = await getCaptureEnabled();
  const allowlist = await getAllowlist();
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (tab.id == null || !tab.url) continue;
    const host = parseHost2(tab.url);
    const matches = enabled && allowlist.length > 0 && hostMatchesAllowlist(host, allowlist);
    if (matches) {
      if (!stickyTabs.has(tab.id)) {
        stickyTabs.add(tab.id);
      }
      if (!capture.isAttached(tab.id)) {
        await capture.attach(tab.id);
        await injectCaptchaScanner(tab.id, tab.url);
      }
    } else if (enabled && stickyTabs.has(tab.id)) {
      if (!capture.isAttached(tab.id)) await capture.attach(tab.id);
    } else if (capture.isAttached(tab.id)) {
      await capture.detach(tab.id);
      stickyTabs.delete(tab.id);
    }
  }
  await persistSticky();
}
async function maybeAttachTab(tabId, url) {
  if (!url) return;
  tabPageUrl.set(tabId, url);
  const host = parseHost2(url);
  if (host) await recordHost(host);
  const enabled = await getCaptureEnabled();
  if (!enabled) {
    if (capture.isAttached(tabId)) await capture.detach(tabId);
    if (stickyTabs.delete(tabId)) await persistSticky();
    injectedScanner.delete(tabId);
    return;
  }
  const allowlist = await getAllowlist();
  const matches = host && hostMatchesAllowlist(host, allowlist);
  if (matches) {
    if (!stickyTabs.has(tabId)) {
      stickyTabs.add(tabId);
      await persistSticky();
    }
    await capture.attach(tabId);
    await injectCaptchaScanner(tabId, url);
  } else if (stickyTabs.has(tabId)) {
    await capture.attach(tabId);
    await injectCaptchaScanner(tabId, url);
  } else {
    if (capture.isAttached(tabId)) await capture.detach(tabId);
    injectedScanner.delete(tabId);
  }
}
async function captureTab(tabId) {
  stickyTabs.add(tabId);
  await persistSticky();
  await capture.attach(tabId);
  const url = tabPageUrl.get(tabId);
  if (url) await injectCaptchaScanner(tabId, url);
}
async function uncaptureTab(tabId) {
  stickyTabs.delete(tabId);
  await persistSticky();
  const url = tabPageUrl.get(tabId);
  const host = parseHost2(url);
  const allowlist = await getAllowlist();
  if (!(host && hostMatchesAllowlist(host, allowlist))) {
    await capture.detach(tabId);
    injectedScanner.delete(tabId);
  }
}
async function disableCapture() {
  await capture.detachAll();
  stickyTabs.clear();
  injectedScanner.clear();
  await persistSticky();
}
async function injectCaptchaScanner(tabId, url) {
  const last = injectedScanner.get(tabId);
  if (last === url) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      files: ["content-captcha.js"]
    });
    try {
      await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ["content-js-capture.js"]
      });
    } catch {
    }
    injectedScanner.set(tabId, url);
  } catch {
  }
}
async function broadcastStatus() {
  bridge.send({
    kind: "status",
    capturing: await getCaptureEnabled(),
    allowlist: await getAllowlist(),
    scope: currentScope,
    attachedTabs: capture.attachedCount()
  });
}
async function hydrateState() {
  currentScope = await getCaptureScope();
  const sticky = await getStickyTabs();
  for (const id of sticky) stickyTabs.add(id);
}
chrome.alarms.create(KEEP_ALIVE_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== KEEP_ALIVE_ALARM) return;
  await getCaptureEnabled();
  if (!bridge.isOpen()) bridge.forceReconnect();
});
chrome.runtime.onInstalled.addListener(async () => {
  await hydrateState();
  bridge.start();
  syncTabsWithAllowlist();
});
chrome.runtime.onStartup.addListener(async () => {
  await hydrateState();
  bridge.start();
  syncTabsWithAllowlist();
});
bridge.onAuthenticated(async () => {
  try {
    await broadcastStatus();
  } catch (e) {
    console.warn("[bridge] post-auth sync failed", e);
  }
});
hydrateState();
bridge.start();
chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return;
  await maybeAttachTab(details.tabId, details.url);
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (capture.isAttached(tabId)) capture.detach(tabId);
  tabPageUrl.delete(tabId);
  injectedScanner.delete(tabId);
  if (stickyTabs.delete(tabId)) await persistSticky();
});
chrome.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== "loading" || !tab.url) return;
  await maybeAttachTab(tabId, tab.url);
});
bridge.onMessage(async (msg) => {
  if (msg.kind === "set-allowlist") {
    await setAllowlist(msg.domains);
    bridge.send({ kind: "allowlist-sync", domains: await getAllowlist() });
    await syncTabsWithAllowlist();
  } else if (msg.kind === "set-capture") {
    await setCaptureEnabled(msg.enabled);
    if (!msg.enabled) await disableCapture();
    else await syncTabsWithAllowlist();
    await broadcastStatus();
  } else if (msg.kind === "set-capture-scope") {
    currentScope = msg.scope;
    await setCaptureScope(msg.scope);
    await broadcastStatus();
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg?.kind === "popup-get-state") {
      const activeId = await resolveActiveTabId(msg.tabId);
      sendResponse({
        capturing: await getCaptureEnabled(),
        allowlist: await getAllowlist(),
        scope: currentScope,
        connected: bridge.isOpen(),
        attachedTabs: capture.attachedCount(),
        token: await getToken(),
        recentHosts: await getRecentHosts(),
        activeTabSticky: activeId != null && stickyTabs.has(activeId)
      });
    } else if (msg?.kind === "popup-set-allowlist") {
      await setAllowlist(msg.domains ?? []);
      await syncTabsWithAllowlist();
      bridge.send({ kind: "allowlist-sync", domains: await getAllowlist() });
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-set-capture") {
      await setCaptureEnabled(!!msg.enabled);
      if (msg.enabled) await syncTabsWithAllowlist();
      else await disableCapture();
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-set-scope") {
      currentScope = msg.scope === "all" ? "all" : "data";
      await setCaptureScope(currentScope);
      await broadcastStatus();
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-capture-tab") {
      const tid = await resolveActiveTabId(msg.tabId);
      if (tid != null) await captureTab(tid);
      sendResponse({ ok: tid != null });
    } else if (msg?.kind === "popup-uncapture-tab") {
      const tid = await resolveActiveTabId(msg.tabId);
      if (tid != null) await uncaptureTab(tid);
      sendResponse({ ok: tid != null });
    } else if (msg?.kind === "popup-set-token") {
      await setToken(String(msg.token ?? ""));
      bridge.forceReconnect();
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-set-remote-token") {
      const { setRemoteToken: setRemoteToken2 } = await Promise.resolve().then(() => (init_remote_store(), remote_store_exports));
      await setRemoteToken2(String(msg.token ?? ""));
      remoteBridge.forceReconnect();
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-set-remote-enabled") {
      const { setRemoteEnabled: setRemoteEnabled2 } = await Promise.resolve().then(() => (init_remote_store(), remote_store_exports));
      await setRemoteEnabled2(!!msg.enabled);
      if (msg.enabled) remoteBridge.forceReconnect();
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-set-remote-url") {
      const { setRemoteBridgeUrl: setRemoteBridgeUrl2 } = await Promise.resolve().then(() => (init_remote_store(), remote_store_exports));
      await setRemoteBridgeUrl2(String(msg.url ?? ""));
      remoteUrlCache = String(msg.url ?? "") || "wss://capture.eemaill.codes/bridge/ws";
      remoteBridge.forceReconnect();
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-get-remote-state") {
      const { getRemoteEnabled: getRemoteEnabled2, getRemoteBridgeUrl: getRemoteBridgeUrl2, getRemoteToken: getRemoteToken2 } = await Promise.resolve().then(() => (init_remote_store(), remote_store_exports));
      sendResponse({
        ok: true,
        enabled: await getRemoteEnabled2(),
        url: await getRemoteBridgeUrl2(),
        token: await getRemoteToken2(),
        localConnected: localBridge.isOpen(),
        remoteConnected: remoteBridge.isOpen(),
        debuggerAttached: capture.attachedCount(),
        fallbackActive: true,
        captureMode: capture.attachedCount() > 0 ? "debugger" : "webRequest-fallback"
      });
    } else if (msg?.kind === "js-capture") {
      const tabId = _sender.tab?.id ?? -1;
      const pageUrl = _sender.tab?.url ?? msg.pageUrl ?? "";
      let pageHost = "";
      try {
        pageHost = pageUrl ? new URL(pageUrl).host : "";
      } catch {
      }
      const allowlist = await getAllowlist();
      const allowed = pageHost && hostMatchesAllowlist(pageHost, allowlist) || tabId >= 0 && (stickyTabs.has(tabId) || capture.isAttached(tabId));
      if (!allowed) {
        sendResponse({ ok: false, error: "host-not-allowlisted" });
        return;
      }
      const jsDedupeKey = requestDedupeKey(tabId, msg.method || "GET", msg.url || "");
      const nowJs = Date.now();
      const lastJs = Math.max(jsDedupe.get(jsDedupeKey) ?? 0, cdpDedupe.get(jsDedupeKey) ?? 0);
      if (nowJs - lastJs < JS_DEDUPE_MS) {
        sendResponse({ ok: true, deduped: true });
        return;
      }
      jsDedupe.set(jsDedupeKey, nowJs);
      cdpDedupe.set(jsDedupeKey, nowJs);
      if (jsDedupe.size > 2e3) {
        const first = jsDedupe.keys().next().value;
        if (first) jsDedupe.delete(first);
      }
      bridge.send({
        kind: "request",
        payload: {
          id: `js:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`,
          tabId,
          source: "web",
          type: "Script",
          method: msg.method ?? "JS",
          url: msg.url ?? `inline://${msg.subtype ?? "capture"}`,
          host: pageHost,
          startedAt: Date.now(),
          requestHeaders: [],
          responseHeaders: [],
          requestBody: typeof msg.body === "string" ? msg.body.slice(0, 2e5) : void 0,
          initiator: `js-capture:${msg.subtype ?? "unknown"}`
        }
      });
      sendResponse({ ok: true });
    } else if (msg?.kind === "popup-clear-recent") {
      await clearRecentHosts();
      sendResponse({ ok: true });
    } else if (msg?.kind === "content-captcha-detected") {
      const tabId = _sender.tab?.id ?? -1;
      const pageUrl = _sender.tab?.url ?? msg.pageUrl ?? "";
      let pageHost = "";
      try {
        pageHost = pageUrl ? new URL(pageUrl).host : "";
      } catch {
      }
      const allowlist = await getAllowlist();
      const allowed = pageHost && hostMatchesAllowlist(pageHost, allowlist) || tabId >= 0 && (stickyTabs.has(tabId) || capture.isAttached(tabId));
      if (!allowed) {
        sendResponse({ ok: false, error: "host-not-allowlisted" });
        return;
      }
      const type = msg.type;
      const sitekey = String(msg.sitekey ?? "");
      emitCaptcha({
        id: stableId(type, sitekey, pageHost),
        type,
        sitekey,
        pageUrl,
        pageHost,
        sourceUrl: pageUrl,
        source: msg.source === "script" ? "script" : "dom",
        detectedAt: Date.now(),
        tabId,
        extra: msg.extra
      });
      sendResponse({ ok: true });
    } else {
      sendResponse({ ok: false, error: "unknown" });
    }
  })();
  return true;
});
async function resolveActiveTabId(explicit) {
  if (typeof explicit === "number") return explicit;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id ?? null;
}

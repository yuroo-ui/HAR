// src/popup.ts
var $ = (id) => document.getElementById(id);
async function getActiveTabId() {
  try {
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    return t?.id ?? void 0;
  } catch {
    return void 0;
  }
}
async function getState() {
  const tabId = await getActiveTabId();
  return await chrome.runtime.sendMessage({ kind: "popup-get-state", tabId });
}
async function getRemoteState() {
  try {
    return await chrome.runtime.sendMessage({ kind: "popup-get-remote-state" });
  } catch {
    return { ok: false, enabled: false, url: "", token: "" };
  }
}
var SCOPE_HINTS = {
  data: "Captures XHR/Fetch/WebSocket, page loads, form-POST signups (Document), beacons. Skips images, CSS, fonts, scripts.",
  all: "Captures every resource type, including static assets. Larger HARs."
};
function activeTabHost() {
  return chrome.tabs.query({ active: true, currentWindow: true }).then(([t]) => {
    if (!t?.url) return "";
    try {
      return new URL(t.url).host;
    } catch {
      return "";
    }
  }).catch(() => "");
}
function renderRecent(hosts, allowlist) {
  const list = $("recent-list");
  list.innerHTML = "";
  if (hosts.length === 0) {
    list.innerHTML = '<div class="empty">No recent activity yet. Visit some sites.</div>';
    return;
  }
  for (const h of hosts) {
    const row = document.createElement("div");
    row.className = "recent-item";
    const inList = allowlist.includes(h.host);
    row.innerHTML = `
      <span class="host" title="${h.host}">${h.host}</span>
      <span class="count">${h.count}\xD7</span>
      <button class="add ${inList ? "in" : ""}" data-host="${h.host}">${inList ? "\u2713 added" : "\uFF0B add"}</button>
    `;
    list.appendChild(row);
  }
  list.querySelectorAll("button.add").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const host = btn.dataset.host;
      const s = await getState();
      if (s.allowlist.includes(host)) return;
      const next = Array.from(/* @__PURE__ */ new Set([...s.allowlist, host]));
      await chrome.runtime.sendMessage({ kind: "popup-set-allowlist", domains: next });
      render(await getState());
    });
  });
}
function renderScope(scope) {
  for (const btn of document.querySelectorAll("#scope button")) {
    btn.classList.toggle("active", btn.dataset.scope === scope);
  }
  $("scope-hint").textContent = SCOPE_HINTS[scope];
}
async function render(state) {
  $("capture").checked = state.capturing;
  $("capture-sub").textContent = state.capturing ? state.attachedTabs > 0 ? `Active \xB7 ${state.attachedTabs} tab${state.attachedTabs === 1 ? "" : "s"} capturing` : state.allowlist.length ? "On \xB7 visit an allowlisted site" : "On \xB7 add a domain to start" : "Off";
  renderScope(state.scope);
  const allowlistEl = $("allowlist");
  if (document.activeElement !== allowlistEl) {
    const fromState = state.allowlist.join("\n");
    if (allowlistEl.value !== fromState) allowlistEl.value = fromState;
  }
  const tokenEl = $("token");
  if (document.activeElement !== tokenEl) {
    const fromState = state.token ?? "";
    if (tokenEl.value !== fromState) tokenEl.value = fromState;
  }
  const hasToken = !!(state.token || "").trim();
  $("conn").innerHTML = `<span class="dot ${state.connected ? "on" : "off"}"></span>${state.connected ? "Connected" : hasToken ? "Connecting\u2026" : "No token"}`;
  $("status").innerHTML = `<span class="dot ${state.capturing ? "on" : "off"}"></span>${state.capturing ? `Capturing \xB7 ${state.allowlist.length} domain${state.allowlist.length === 1 ? "" : "s"} \xB7 ${state.attachedTabs} tab${state.attachedTabs === 1 ? "" : "s"}` : "Capture disabled"}`;
  const host = await activeTabHost();
  $("active-tab-host").textContent = host ? `Active tab: ${host}` : "";
  const btn = $("capture-tab");
  if (state.activeTabSticky) {
    btn.textContent = "\u25A0 Stop capturing this tab";
    btn.classList.add("warn");
    btn.classList.remove("secondary");
  } else {
    btn.textContent = "\uFF0B Capture this tab";
    btn.classList.add("secondary");
    btn.classList.remove("warn");
  }
}
function activateTab(name) {
  for (const t of document.querySelectorAll(".tab")) {
    t.classList.toggle("active", t.dataset.tab === name);
  }
  for (const id of ["main", "recent", "remote", "auth"]) {
    const el = $(`tab-${id}`);
    if (el) el.style.display = id === name ? "" : "none";
  }
}
async function refreshRemote() {
  const rs = await getRemoteState();
  const enabledEl = $("remote-enabled");
  const urlEl = $("remote-url");
  const tokenEl = $("remote-token");
  const statusEl = $("remote-status");
  if (!enabledEl) return;
  if (document.activeElement !== enabledEl) enabledEl.checked = !!rs.enabled;
  if (urlEl && document.activeElement !== urlEl) {
    const desired = rs.url || "wss://capture.eemaill.codes/bridge/ws";
    if (urlEl.value !== desired) urlEl.value = desired;
  }
  if (tokenEl && document.activeElement !== tokenEl) {
    if (tokenEl.value !== (rs.token || "")) tokenEl.value = rs.token || "";
  }
  if (statusEl) {
    statusEl.textContent = rs.enabled ? "Remote ON \u2014 streaming to server." : "Remote OFF.";
  }
}
async function init() {
  render(await getState());
  refreshRemote();
  document.querySelectorAll(".tab").forEach((t) => {
    t.addEventListener("click", () => activateTab(t.dataset.tab));
  });
  $("capture").addEventListener("change", async (e) => {
    const enabled = e.target.checked;
    await chrome.runtime.sendMessage({ kind: "popup-set-capture", enabled });
    render(await getState());
  });
  document.querySelectorAll("#scope button").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const scope = btn.dataset.scope;
      renderScope(scope);
      await chrome.runtime.sendMessage({ kind: "popup-set-scope", scope });
      render(await getState());
    });
  });
  $("capture-tab").addEventListener("click", async () => {
    const s = await getState();
    const tabId = await getActiveTabId();
    const kind = s.activeTabSticky ? "popup-uncapture-tab" : "popup-capture-tab";
    await chrome.runtime.sendMessage({ kind, tabId });
    render(await getState());
  });
  $("save").addEventListener("click", async () => {
    const text = $("allowlist").value;
    const domains = text.split(/\r?\n/).map((s) => s.trim().toLowerCase()).filter(Boolean);
    await chrome.runtime.sendMessage({ kind: "popup-set-allowlist", domains });
    render(await getState());
  });
  $("reload").addEventListener("click", async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    for (const t of tabs) if (t.id != null) chrome.tabs.reload(t.id);
  });
  $("save-token").addEventListener("click", async () => {
    const token = $("token").value.trim();
    await chrome.runtime.sendMessage({ kind: "popup-set-token", token });
    setTimeout(async () => render(await getState()), 600);
  });
  $("clear-recent").addEventListener("click", async () => {
    await chrome.runtime.sendMessage({ kind: "popup-clear-recent" });
    render(await getState());
  });
  const remoteEnabledEl = $("remote-enabled");
  if (remoteEnabledEl) {
    remoteEnabledEl.addEventListener("change", async (e) => {
      const enabled = e.target.checked;
      await chrome.runtime.sendMessage({ kind: "popup-set-remote-enabled", enabled });
      refreshRemote();
    });
  }
  const saveRemoteBtn = $("save-remote");
  if (saveRemoteBtn) {
    saveRemoteBtn.addEventListener("click", async () => {
      const url = $("remote-url").value.trim();
      const token = $("remote-token").value.trim();
      const enabled = $("remote-enabled").checked;
      if (url) await chrome.runtime.sendMessage({ kind: "popup-set-remote-url", url });
      await chrome.runtime.sendMessage({ kind: "popup-set-remote-token", token });
      await chrome.runtime.sendMessage({ kind: "popup-set-remote-enabled", enabled });
      const sEl = $("remote-status");
      if (sEl) sEl.textContent = "Saved. Reconnecting\u2026";
      setTimeout(() => refreshRemote(), 800);
    });
  }
  const refreshRecent = async () => {
    const s = await getState();
    renderRecent(s.recentHosts, s.allowlist);
  };
  refreshRecent();
  setInterval(async () => {
    const s = await getState();
    render(s);
    renderRecent(s.recentHosts, s.allowlist);
    refreshRemote();
  }, 2e3);
}
init();
